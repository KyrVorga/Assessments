insert into SubscriberType
    (SubscriptionName)
values 
    ('Standard'),
    ('Gold'),
    ('Platinum'),
    ('Super Platinum');