insert into 
    Supplier (CompanyName)
values 
    ('Kwilith'),
    ('Meemm'),
    ('Zoomcast'),
    ('Eadel'),
    ('Voolia'),
    ('Ozu'),
    ('Jetwire'),
    ('Wordtune'),
    ('Rhynyx'),
    ('Gabtype');
