insert into
    AccessAction (ActionName)
values
    ('View'),
    ('Create'),
    ('Control');