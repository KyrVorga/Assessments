insert into
    Executive (StaffID)
values
    (754),
    (36),
    (810),
    (153),
    (493),
    (893),
    (613),
    (352),
    (103),
    (918);