insert into Country
    (CountryName)
values
    ('New Zealand'),
    ('Australia'),
    ('United Kingdom'),
    ('United States');